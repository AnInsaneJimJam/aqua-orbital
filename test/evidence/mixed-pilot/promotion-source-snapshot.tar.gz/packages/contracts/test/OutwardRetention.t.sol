// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;
import {Test} from "forge-std/Test.sol";
import {OrbitalMath as M} from "../src/libraries/OrbitalMath.sol";
import {TickGeometry as G} from "../src/libraries/TickGeometry.sol";
import {FrontierComposition as C} from "../src/libraries/FrontierComposition.sol";
import {FrontierEndpoint as E} from "../src/libraries/FrontierEndpoint.sol";
import {RootBracket as B} from "../src/libraries/RootBracket.sol";
import {SlackCertificate as P} from "../src/libraries/SlackCertificate.sol";

contract RetentionTestClient {
    uint256 public marker=0xdecaf;
    function quote(uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d,uint8 limit) external view returns(C.Result memory r,uint256 body){
        uint256 before=gasleft();r=C.certify(x,ticks,d,0,2,68669858,limit);body=before-gasleft();
    }
}
contract OutwardRetentionTest is Test {
    uint256 constant GRID=1<<32;uint256 constant U=1<<64;
    uint256 constant ONE_ROOT=6443637668976165642222101835317088018659474232792;uint256 constant SEVEN_ROOT=6443637668976165642222101835317088018659474232792;
    uint256 constant ONE_SHORTFALL=9012415530112750346015845354028;uint256 constant SEVEN_SHORTFALL=12356708104142462939140874015845354028;
    uint256 constant ONE_SLACK=7965299770447535177748415426220;uint256 constant SEVEN_SLACK=10919597907346954110716214158176631787;
    RetentionTestClient client;
    function setUp() public {client=new RetentionTestClient();}
    function fixture(bool seven) private pure returns(uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d){
        uint256 whole=1e18*U;x=new uint256[](3);x[0]=500*whole;x[1]=400*whole;x[2]=100*whole;
        d=new uint8[](3);d[0]=6;d[1]=6;d[2]=seven?0:6;
        ticks=new M.Tick[](seven?8:3);
        for(uint256 i;i+1<ticks.length;i++){
            uint64 key=seven?uint64(3*GRID/2+i):uint64(i==0?3*GRID/2:7*GRID/4);
            uint256 radius=seven?(i==6?40:10)*whole:(i==0?100:200)*whole;
            ticks[i]=M.Tick(key,uint192(radius),G.coefficients(3,key));
        }
        ticks[ticks.length-1]=M.Tick(type(uint64).max,uint192((seven?600:400)*whole),G.coefficients(3,type(uint64).max));
    }
    function assertEndpoint(E.Result memory r,M.Tick[] memory ticks,bool seven) private pure {
        assertEq(uint256(r.status),uint256(E.Status.EndpointCertified));assertTrue(r.root.identified);
        assertEq(r.root.boundaryCount,0);assertEq(r.actualBoundaryCount,seven?7:1);assertEq(r.retentionCrossings,seven?7:1);
        assertEq(r.amountOutRaw,seven?18:18669858);assertTrue(M.certify(r.reserves,ticks));
        uint256 root=seven?SEVEN_ROOT:ONE_ROOT;
        assertLe(r.root.bracket.lo,root);assertGe(r.root.bracket.hi,root+1);
        assertGe(r.shortfallUpper,seven?SEVEN_SHORTFALL:ONE_SHORTFALL);
        assertGe(r.shortfallUpper,seven?SEVEN_SLACK:ONE_SLACK);assertLe(r.shortfallUpper,r.outputQuantum);
        assertEq(r.reserves[0],(500*1e18+68669858*1e12)*U);assertEq(r.reserves[1],400*1e18*U);
        assertEq(r.reserves[2],100*1e18*U-r.amountOutRaw*r.outputQuantum);
    }
    function endpoint(bool seven,bool targeted) private returns(E.Result memory r){
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(seven);
        bytes32 saved=keccak256(abi.encode(x,ticks,d));
        r=targeted?E.exactInputForPayout(x,ticks,d,0,2,68669858,0,160):E.exactInput(x,ticks,d,0,2,68669858,0,160);
        assertEndpoint(r,ticks,seven);assertEq(keccak256(abi.encode(x,ticks,d)),saved);
        (bool valid,uint8 crossed)=P.certifyInwardReleaseToGrid(r.reserves,ticks,2,r.root.bracket.hi,0);
        assertTrue(valid);assertEq(crossed,r.retentionCrossings);
    }
    function testExactSeamEndpointCertifiesActualEqualityPrefixOnce() public {endpoint(false,false);}
    function testSevenSeamEndpointUsesOneCombinedRawQuantum() public {endpoint(true,false);}
    function testTargetedSingleSeamRetainsCertifiedRootAndFinalMetadata() public {endpoint(false,true);}
    function testTargetedSevenSeamsRetainOneRawFloor() public {endpoint(true,true);}
    function measure(bool seven) private returns(C.Result memory r){
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(seven);uint8 crossings=seven?7:1;
        vm.cool(address(C));vm.cool(address(E));vm.cool(address(client));
        uint256 before=gasleft();uint256 body;(r,body)=client.quote(x,ticks,d,crossings);uint256 externalGas=before-gasleft();
        emit log_string(seven?"seven retention seams":"one exact retention seam");
        emit log_named_uint("cold_external_call_gas",externalGas);emit log_named_uint("linked_body_gas",body);
        emit log_named_uint("first_used",r.firstSolveUsed);emit log_named_uint("resume_used",r.resumeUsed);
        assertEq(uint256(r.status),uint256(C.Status.FrontierPathCertified));assertEndpoint(r.endpoint,ticks,seven);
        assertEq(r.releaseCrossings,0);assertEq(r.frontierCrossings,0);assertEq(r.retentionCrossings,crossings);
        assertEq(r.transitions.length,crossings);assertEq(r.crossingRemaining,0);
        assertEq(uint256(r.refinementUsed)+r.refinementRemaining,160);
        assertEq(uint256(r.firstSolveUsed)+r.resumeUsed,r.refinementUsed);
        for(uint256 i;i<crossings;i++){
            assertEq(r.transitions[i].key,ticks[i].key);assertFalse(r.transitions[i].inward);
            assertFalse(r.transitions[i].initialRelease);assertTrue(r.transitions[i].finalRetention);
        }
        assertEq(client.marker(),0xdecaf);
    }
    function testSingleRetentionTransitionHasAnExplicitAccountingPhase() public {measure(false);}
    function testSevenRetentionTransitionsAreAscendingAndChargedOnce() public {measure(true);}
    function insufficient(bool seven) private {
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(seven);
        (C.Result memory r,)=client.quote(x,ticks,d,seven?6:0);
        assertEq(uint256(r.status),uint256(C.Status.TransitionLimit));
        assertEq(uint256(r.endpoint.status),uint256(E.Status.EndpointCertified));assertEq(r.transitions.length,0);
        assertEq(uint256(r.refinementUsed)+r.refinementRemaining,160);
    }
    function testOneLessThanSingleRetentionAllowanceCannotAuthorizePayout() public {insufficient(false);}
    function testOneLessThanSevenRetentionAllowanceCannotAuthorizePayout() public {insufficient(true);}
    function testReverseCertificateConsumesFinalFixedInputFrame() public {
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(false);
        E.Result memory r=E.exactInput(x,ticks,d,0,2,68669858,0,160);assertEndpoint(r,ticks,false);
        (bool wrong,)=P.certifyInwardReleaseToGrid(x,ticks,2,r.root.bracket.hi,0);assertFalse(wrong);
        (bool right,)=P.certifyInwardReleaseToGrid(r.reserves,ticks,2,r.root.bracket.hi,0);assertTrue(right);
    }
    function testChangedFrameCannotReusePreviousRootBounds() public {
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(false);
        E.Result memory r=E.exactInput(x,ticks,d,0,2,68669858,0,160);assertEndpoint(r,ticks,false);
        E.Result memory wrong=E.resumeExactInput(x,ticks,d,0,2,68669859,0,r.root.bracket.lo,r.root.bracket.hi,0);
        assertFalse(wrong.root.identified);assertTrue(wrong.status!=E.Status.EndpointCertified);
    }
    function testUncertifiedHighCannotAuthorizeReverseRetention() public {
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(false);
        E.Result memory r=E.exactInput(x,ticks,d,0,2,68669858,0,160);assertEndpoint(r,ticks,false);
        E.Result memory wrong=E.resumeExactInput(x,ticks,d,0,2,68669858,0,r.root.bracket.lo,x[2]*GRID,0);
        assertFalse(wrong.root.identified);assertTrue(wrong.status!=E.Status.EndpointCertified);
    }
    function testZeroBudgetResumeCanFinalizeOnlyCertifiedRetainedIdentity() public {
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(true);
        E.Result memory first=E.exactInputForPayout(x,ticks,d,0,2,68669858,0,160);assertEndpoint(first,ticks,true);
        E.Result memory resumed=E.resumeExactInput(x,ticks,d,0,2,68669858,0,first.root.bracket.lo,first.root.bracket.hi,0);
        assertEndpoint(resumed,ticks,true);assertEq(resumed.root.bracket.used,0);assertEq(resumed.root.bracket.remaining,0);
        assertEq(resumed.amountOutRaw,first.amountOutRaw);
    }
    function testMalformedMetadataCannotAcquireRetentionCertificate() public {
        (uint256[] memory x,M.Tick[] memory ticks,uint8[] memory d)=fixture(false);
        d[2]=19;vm.expectRevert(E.InvalidMetadata.selector);E.exactInput(x,ticks,d,0,2,68669858,0,160);
        d[2]=6;ticks[0].radius=0;E.Result memory r=E.exactInput(x,ticks,d,0,2,68669858,0,160);
        assertEq(uint256(r.status),uint256(E.Status.UncertifiedStart));assertEq(r.retentionCrossings,0);
    }
    function testPriorReleaseAndIdealEventsKeepTheirDistinctPhases() public pure {
        uint256 scale=1e40;uint256[] memory x=new uint256[](2);x[0]=15*scale/10;x[1]=3*scale/10;
        uint64 key=uint64(7*GRID/8);M.Tick[] memory ticks=new M.Tick[](2);
        ticks[0]=M.Tick(key,uint192(scale),G.coefficients(2,key));ticks[1]=M.Tick(type(uint64).max,uint192(scale),G.coefficients(2,type(uint64).max));
        uint8[] memory d=new uint8[](2);d[0]=18;d[1]=18;
        C.Result memory r=C.certify(x,ticks,d,0,1,35*scale/100/U,2);
        assertEq(uint256(r.status),uint256(C.Status.FrontierPathCertified));assertEq(r.endpoint.amountOutRaw,157670507261635933550);
        assertEq(r.retentionCrossings,0);assertEq(r.endpoint.retentionCrossings,0);
        assertEq(r.endpoint.actualBoundaryCount,r.endpoint.root.boundaryCount);
        assertEq(r.transitions.length,2);assertTrue(r.transitions[0].initialRelease);assertTrue(r.transitions[0].inward);
        assertFalse(r.transitions[1].initialRelease);assertFalse(r.transitions[1].inward);
        assertFalse(r.transitions[0].finalRetention);assertFalse(r.transitions[1].finalRetention);
    }
    function testReverseReleaseKeepsTheHiddenBoundaryMaximumRejection() public pure {
        uint256 scale=1e40;uint64 key=uint64(7*GRID/4);M.Tick[] memory ticks=new M.Tick[](2);
        ticks[0]=M.Tick(key,uint192(scale/100),G.coefficients(3,key));
        ticks[1]=M.Tick(type(uint64).max,uint192(10*scale),G.coefficients(3,type(uint64).max));
        uint256[] memory actual=new uint256[](3);actual[0]=61*scale/10;actual[1]=6*scale;actual[2]=61*scale/10;
        uint256 end=56*scale/10*GRID+1;uint256[] memory high=new uint256[](3);
        for(uint256 i;i<3;i++)high[i]=actual[i]*GRID;high[2]=end;
        assertTrue(M.certify(actual,ticks));assertTrue(M.certifyGridPoint(high,ticks,1));
        (bool valid,)=P.certifyInwardReleaseToGrid(actual,ticks,2,end,1);assertFalse(valid);
    }
    function testDeployableLinkedRuntimeSizes() public {
        emit log_named_uint("composition_runtime_bytes",address(C).code.length);
        emit log_named_uint("endpoint_runtime_bytes",address(E).code.length);
        emit log_named_uint("client_runtime_bytes",address(client).code.length);
        assertGt(address(C).code.length,0);assertLe(address(C).code.length,24576);
        assertGt(address(E).code.length,0);assertLe(address(E).code.length,24576);
        assertLe(address(client).code.length,24576);
    }
}
